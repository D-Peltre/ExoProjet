<?php

include 'connection.php';

    $pseudo=$_POST['pseudo'];
    $pass = md5($_POST['password']);
    $confirm = md5($_POST['confirm']);
    $email = $_POST['email'];
    $i = 0;

        //Vérification du pseudo
    $query=$db->prepare('SELECT COUNT(*) AS nbr FROM User WHERE Pseudo =:pseudo');
    $query->bindValue(':pseudo',$pseudo, PDO::PARAM_STR);
    $query->execute();
    $pseudo_free=($query->fetchColumn()==0)?1:0;
    $query->CloseCursor();
    if(!$pseudo_free)
    {
        $pseudo_erreur1 = "Votre pseudo est déjà utilisé par un membre";
        $i++;
    }

    if (strlen($pseudo) < 6 || strlen($pseudo) > 15)
    {
        $pseudo_erreur2 = "Votre pseudo est soit trop grand, soit trop petit";
        $i++;
    }

    //Vérification du mdp

    if (strlen($pass) < 6 || strlen($pass) > 15)
    {
        $pseudo_erreur2 = "Votre mot de passe est soit trop grand, soit trop petit";
        $i++;
    }

    if ($pass != $confirm || empty($confirm) || empty($pass))
    {
        $mdp_erreur = "Votre mot de passe et votre confirmation diffèrent, ou sont vides";
        $i++;
    }

    if ($i==0)
	{
	echo'<h1>Inscription terminée</h1>';
    echo'<p>Bienvenue '. $_POST['pseudo'] .' vous êtes maintenant inscrit sur le site</p>';
	}
?>
