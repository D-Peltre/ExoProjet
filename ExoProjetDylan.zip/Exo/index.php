<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
    <link rel="stylesheet" href="style.css" />
	<title>Acceuil</title>
</head>
<body>

	<form action="verifconnection.php" method="post">
		<fieldset>
			<legend>Connexion</legend>
			<p>
				<label for="pseudo">Pseudo :</label><input name="pseudo" type="text" id="pseudo" /><br />
				<label for="password">Mot de Passe :</label><input type="password" name="password" id="password" />
			</p>
		</fieldset>
		<p><input type="submit"  value="Connexion" /></p></form>
		<a href="register.php">Pas encore inscrit ?</a>
	</form>




</body>
</html>
