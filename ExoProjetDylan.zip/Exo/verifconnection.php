 <?php

include 'connection.php';

 	if (empty($_POST['pseudo']) || empty($_POST['password']) ) //Oublie d'un champ
    {
        $message = '<p>une erreur s\'est produite pendant votre identification.
	Vous devez remplir tous les champs</p>
	<p>Cliquez <a href="index.php">ici</a> pour revenir</p>';
    }
    else //On check le mot de passe
    {
        $query=$db->prepare('SELECT Password, Id, Pseudo
        FROM User WHERE Pseudo = :pseudo');
        $query->bindValue(':pseudo',$_POST['pseudo'], PDO::PARAM_STR);
        $query->execute();
        $data=$query->fetch();

		if ($data['Password'] == md5($_POST['password'])) // Acces OK !
		{
		    $_SESSION['pseudo'] = $data['Pseudo'];
		    $_SESSION['id'] = $data['Id'];


		    $message = '<p>Bienvenue '.$data['Pseudo'].', 
				vous êtes maintenant connecté!</p>
				<p>Cliquez <a href="index.php">ici</a> 
				pour revenir à la page d accueil</p>';  

		
			'<script type="text/JavaScript">
				function changerCouleur (id, couleur){
  					document.getElementById(id).style.backgroundColor="green";
  				}
				
			</script>'

		
			
		}
		
	    $query->CloseCursor();
    }
    echo $message;


?>

