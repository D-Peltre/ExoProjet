<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
    <link rel="stylesheet" href="style.css" />
	<title>Inscription</title>
</head>
<body>
	<h1>Inscription</h1>
	<form method="post" action="registerphp.php" enctype="multipart/form-data">
		<fieldset><legend>Identifiants</legend>
			<label for="pseudo">* Pseudo :</label>  <input name="pseudo" type="text" id="pseudo" /> (le pseudo doit contenir entre 6 et 15 caractères)<br />
			<label for="password">* Mot de Passe :</label><input type="password" name="password" id="password" /> (au moins 8 caractères)<br />
			<label for="confirm">* Confirmer le mot de passe :</label><input type="password" name="confirm" id="confirm" />
		</fieldset>
		<fieldset><legend>Contacts</legend>
			<label for="email">* Votre adresse Mail :</label><input type="text" name="email" id="email" /><br />
		</fieldset>
		<p>Les champs précédés d un * sont obligatoires</p>
		<p><input type="submit" value="S'inscrire" /></p>
	</form>
</body>
</html>



